import argparse
import os
import numpy as np
from visdom import Visdom

parser = argparse.ArgumentParser()
parser.add_argument('-l', '--logdir', default='./logs', help='directory to read logs')


def _visualize(path_to_log_dir):
    losses = np.load(os.path.join(path_to_log_dir, 'losses.npy'))
    print(losses)
    # viz = Visdom()
    # viz.line(losses)
    # 导入必要库
    import matplotlib.pyplot as plt

    # 数据
    x = [ i+1  for i in range(len(losses))]
    # y = [2, 3, 5, 7, 11]

    # 绘图
    plt.plot(x, losses, color='b')  # `marker`表示数据点样式
    plt.xlabel("epoch")  # 设置X轴标签
    plt.ylabel("loss")  # 设置Y轴标签
    plt.title("epoch vs loss")  # 设置图表标题
    plt.show()


def main(args):
    path_to_log_dir = args.logdir
    _visualize(path_to_log_dir)


if __name__ == '__main__':
    main(parser.parse_args())
