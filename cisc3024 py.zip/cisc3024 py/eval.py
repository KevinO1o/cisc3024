import argparse
import os
from model import Model
from evaluator import Evaluator
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
from sklearn.model_selection import train_test_split
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
import seaborn as sns
from sklearn.metrics import classification_report
parser = argparse.ArgumentParser()
parser.add_argument( '--data_dir', default='./data', help='directory to read LMDB files')
parser.add_argument('--checkpoint',default='D:\ZZZZZZZ_CZY\code\SVHNClassifier-PyTorch-master\logs\model-283000.pth', type=str, help='path to evaluate checkpoint, e.g. ./logs/model-100.pth')


def _eval(path_to_checkpoint_file, path_to_eval_lmdb_dir):
    model = Model()
    model.restore(path_to_checkpoint_file)
    model.cuda()
    # accuracy = Evaluator(path_to_eval_lmdb_dir).evaluate(model)
    # print('Evaluate %s on %s, accuracy = %f' % (path_to_checkpoint_file, path_to_eval_lmdb_dir, accuracy))
    preds,labels= Evaluator(path_to_eval_lmdb_dir).evaluate_roc(model)
    # print(preds,labels)

    # fpr, tpr, thresholds = roc_curve(labels, preds)
    #
    # # 计算AUC值
    # roc_auc = auc(fpr, tpr)
    #
    # # 绘制ROC曲线
    # plt.figure()
    # plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC curve (area = {roc_auc:.2f})')
    # plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')  # 参考线，表示随机猜测的效果
    # plt.xlim([0.0, 1.0])
    # plt.ylim([0.0, 1.05])
    # plt.xlabel('False Positive Rate')
    # plt.ylabel('True Positive Rate')
    # plt.title('Receiver Operating Characteristic (ROC) Curve')
    # plt.legend(loc="lower right")
    # plt.show()

    # cm = confusion_matrix(preds, labels)
    #
    # # 使用seaborn绘制混淆矩阵热力图
    # plt.figure(figsize=(6, 4))
    # sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    # plt.xlabel("Predicted Label")
    # plt.ylabel("True Label")
    # plt.title("Confusion Matrix")
    # plt.show()

    report = classification_report(preds, labels, output_dict=True)

    # 获取每个类别的F1分数
    categories = list(report.keys())[:-3]  # 去掉 "accuracy", "macro avg" 和 "weighted avg"
    f1_scores = [report[category]["f1-score"] for category in categories]

    # 绘制条形图
    plt.figure(figsize=(8, 5))
    plt.bar(categories, f1_scores, color="skyblue")
    plt.xlabel("class ")
    plt.ylabel("F1  score")
    plt.title("every class F1 score")
    plt.ylim(0, 1)  # F1分数范围在0-1之间
    plt.show()
def main(args):
    path_to_test_lmdb_dir = os.path.join(args.data_dir, 'test.lmdb')
    path_to_checkpoint_file = args.checkpoint

    print('Start evaluating')
    _eval(path_to_checkpoint_file, path_to_test_lmdb_dir)
    print('Done')


if __name__ == '__main__':
    main(parser.parse_args())
